#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <main.h>
#include <cmath>
#include <QTimer>  //



CanReceiver::CanReceiver(): my_speed(0), my_rpm(0),my_battery(0), my_throttle(false){

    //Connect to D-Bus and Register and expose the interface
    QDBusConnection::sessionBus().registerService("com.example.CanData");
    QDBusConnection::sessionBus().registerObject("/com/example/CanData/Data", this, QDBusConnection::ExportAllSlots);
    my_gear = "OFF";


//    connect(this, SIGNAL(speedChanged()), this, SLOT(updateSpeed()));
//    connect(this, SIGNAL(rpmChanged()), this, SLOT(updateRpm()));
//    connect(this, SIGNAL(batteryChanged()), this, SLOT(updateBattery()));
//    connect(this, SIGNAL(throttleChanged()), this, SLOT(updateThrottle()));
//    connect(this, SIGNAL(gearChanged()), this, SLOT(updateGear()));

}



double CanReceiver::speed() const{
    return my_speed;
}

double CanReceiver::rpm() const{
    return my_rpm;
}

double CanReceiver::battery() const{
    return my_battery;
}

bool CanReceiver::throttle() const{
    return my_throttle;
}

QString CanReceiver::gear() const{
    if(my_speed == 0){
        return "P";
    }
    else if(my_speed > 0 && my_throttle){
        return "D";
    }
    else if (my_speed > 0 && !my_throttle){
        return "R";
    }
    else{
        return "OFF";
    }
}


void CanReceiver::updateSpeed(double speed){
    my_speed = std::round(speed*10)/10.0;
}

void CanReceiver::updateRpm(double rpm){
    my_rpm = std::round(rpm*10)/ 10.0;
}
void CanReceiver::updateBattery(double battery){
    my_battery = int(battery);
}
void CanReceiver::updateThrottle(bool throttle){
    my_throttle = throttle;
}
void CanReceiver::updateGear(QString gear){
    my_gear = gear;
}



void CanReceiver::setData(double my_speed, double my_rpm, double my_battery, bool my_throttle){

    if(!std::isnan(my_speed)){
        emit speedChanged();
    }
    if(!std::isnan(my_rpm)){
        emit rpmChanged();
    }
    if(!std::isnan(my_battery)){
        emit batteryChanged();
    }
    if(!std::isnan(my_throttle)){
        emit throttleChanged();
    }
    if(!std::isnan(my_throttle) && !std::isnan(my_speed)){
        emit gearChanged();
    }


}

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    CanReceiver canReceiver;

    engine.rootContext()->setContextProperty("canReceiver", &canReceiver);


    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);

    engine.load(url);

    return app.exec();
}
